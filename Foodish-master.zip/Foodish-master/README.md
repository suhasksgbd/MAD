# Foodish
An android shopping cart application for food items which pulls data from an API containing data in JSON format, and displays it with heterogeneous recyclerview.
